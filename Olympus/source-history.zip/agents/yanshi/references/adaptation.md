# 来源与适配决策

只读借鉴 D:/WorkFlow/mattpocock-skills。grilling 提供事实先查、按决策依赖逐个提问并给建议；domain-modeling 提供精确术语与及时记录决定；to-spec 提供信息充分后直接综合；to-tickets 提供完整可验证切片及显式阻塞；writing-great-skills 提供单一信息源、精简入口和按需引用。

本次保留偃师原有三阶段确认，不采用持续盘问直到穷尽所有分支、不重复询问既有决定、不预设长篇用户故事、远程发布或特定平台语法，也不强制串行推进独立任务。来源只借鉴设计思路，未将外部 skill 注册为共工 Agent。

原偃师来源为同工作区 new-chat-2/outputs/yanshi，旧完整版本在整理前历史快照中保留；不修改原项目。Agent 入口由原长描述提炼，保留必要执行细节到按需引用和原工具说明。未声称所有情境下理解效果已经实测。外部材料的 MIT 许可保留于 THIRD_PARTY_LICENSE.txt。
