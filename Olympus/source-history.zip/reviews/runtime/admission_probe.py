from pathlib import Path
import json,sys,subprocess,shutil,hashlib
ROOT=Path(sys.argv[1]).resolve();OUT=Path(__file__).parent/(sys.argv[2] if len(sys.argv)>2 else 'admission-baseline');OUT.mkdir(parents=True,exist_ok=True)
copy=OUT/'copy';shutil.copytree(ROOT,copy,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
manifest=json.loads((copy/'framework-manifest.json').read_text(encoding='utf8'));tests=[]
def invoke(cmd):
 p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8');return {'code':p.returncode,'stdout':p.stdout[:1500],'stderr':p.stderr[:1500]}
def run(name,cmd,expected=True):
 r=invoke(cmd);tests.append({'name':name,'pass':(r['code']==0)==expected,**r})
def changed(name,rel,mutator,cmd,expected=False):
 p=copy/rel;original=p.read_bytes()
 try:
  v=json.loads(original);mutator(v);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8');run(name,cmd,expected)
 finally:p.write_bytes(original)
py=sys.executable;verify=[py,str(copy/'tools/verify_framework.py')]
for a in manifest['agents']:
 cmd=['node',str(copy/'tools/admission.mjs'),str(copy),a['id']]
 run(a['id']+' local admission baseline',cmd)
 changed(a['id']+' pending is not approval',a['admission_pass'],lambda p:p.update(status='pending'),cmd)
 changed(a['id']+' template is not approval',a['admission_pass'],lambda p:p.update(template=True),cmd)
 changed(a['id']+' self approval rejected',a['admission_pass'],lambda p:p['approval'].update(approver_id=p['review']['evaluator_id']),cmd)
 changed(a['id']+' broader scope rejected',a['admission_pass'],lambda p:p['subject']['scope'].append('production_runtime'),cmd)
 changed(a['id']+' expired approval rejected',a['admission_pass'],lambda p:p['approval'].update(expires_at='2020-01-01T00:00:00Z'),cmd)
 entry=copy/a['entry'];old=entry.read_bytes()
 try:entry.write_bytes(old+b'\nSynthetic mutation\n');run(a['id']+' changed entry rejected',cmd,False)
 finally:entry.write_bytes(old)
 run(a['id']+' no host mandate rejected',['node',str(copy/'tools/agent-context.mjs'),a['id']],False)
mandate=OUT/'mandate.json';mandate.write_text(json.dumps({'feature_id':'synthetic','outcome':'local test','authority_ref':'synthetic_not_host_identity'}),encoding='utf8')
run('context loader accepts local declared mandate',['node',str(copy/'tools/agent-context.mjs'),'diting',str(mandate)])
run('full registry baseline',verify)
extra=copy/'agents'/'unregistered';extra.mkdir();(extra/'agent.json').write_text('{}')
run('unregistered agent detected',verify,False)
shutil.rmtree(extra)
extra=copy/'skills'/'unregistered';extra.mkdir();(extra/'SKILL.md').write_text('synthetic')
run('unregistered skill detected',verify,False)
shutil.rmtree(extra)
checks=['node',str(copy/'tools/reporting.mjs'),'--all',str(copy)]
run('all reporting profiles baseline',checks)
a=manifest['agents'][0]
changed('runtime true cannot substitute evidence',a['reporting'],lambda p:p.update(runtime_connected=True),checks)
changed('dependency hash tamper detected',a['reporting'],lambda p:p['dependencies'].update({'tools/diting-report.py':'0'*64}),checks)
# Inspect actual digest coverage independently: include shared implementation and each owned definition.
coverage=[]
for a in manifest['agents']:
 actual={p.relative_to(copy).as_posix() for p in (copy/'agents'/a['id']).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 missing=sorted(actual-set(a['candidate_files']))
 coverage.append({'id':a['id'],'owned_files':len(actual),'missing_from_fingerprint':missing})
result={'framework':str(ROOT),'tests':tests,'owned_fingerprint_coverage':coverage,'scope':'local definition/authentication claims only; no host authority authentication','sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['framework-manifest.json','tools/admission.mjs','tools/reporting.mjs','tools/agent-context.mjs','tools/verify_framework.py','tools/create-component.py']}}
(OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
