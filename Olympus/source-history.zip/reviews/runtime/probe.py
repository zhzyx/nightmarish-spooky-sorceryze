from pathlib import Path
import runpy,json,copy,hashlib,sqlite3,sys,shutil
ROOT=Path(sys.argv[1]).resolve(); OUT=Path(__file__).parent/(sys.argv[2] if len(sys.argv)>2 else 'baseline');OUT.mkdir(parents=True,exist_ok=True)
L=runpy.run_path(str(ROOT/'agents/diting/scripts/ledger.py')); T=L['tel']; R=runpy.run_path(str(ROOT/'tools/diting-report.py'));C=runpy.run_path(str(ROOT/'tools/create-component.py'))
tests=[]
def test(name,fn):
 try:detail=fn();tests.append({'name':name,'pass':True,'detail':detail})
 except Exception as e:tests.append({'name':name,'pass':False,'error':type(e).__name__+': '+str(e)})
def reject(fn):
 try:fn()
 except (ValueError,TypeError,KeyError,sqlite3.Error) as e:return str(e)
 raise AssertionError('unexpectedly accepted')
def eq(a,b):
 assert a==b,(a,b)
 return a
now='2026-11-01T00:00:00Z';tenant='synthetic-review'
ctx={'request_ref':'request','primary_agent_ref':'agent','related_agent_refs':[],'work_items':[{'id':'review','kind':'test','relation':'validates','certainty':'confirmed'}],'linkage_state':'complete','linkage_note':'Synthetic review'}
def rec(rid,kind,payload,refs=None,context=True):
 r={'schema_version':2,'record_id':rid,'tenant_id':tenant,'kind':kind,'created_at':now,'evidence_refs':refs or [],'payload':payload}
 if context:r['context']=copy.deepcopy(ctx)
 return r
def event(rid,kind,payload,refs=None):return rec(rid,kind,{'source_key':'synthetic','event_key':rid,'source_revision':'1',**payload},refs or ['source'])
source=rec('source','source',{'source_key':'synthetic','authority_ref':'synthetic-only','purpose':'isolated test','retention':'temporary','allowed_fields':['synthetic']},context=False)
agent=rec('agent','agent_snapshot',{'agent_id':'review-agent','version':'0.1.0','definition_digest':'1'*64,'definition_ref':'synthetic','origin':'generated','role_kind':'subagent'},['source'],False)
request=event('request','request',{'request_key':'req-key','project_id':'project','initiated_at':now,'intent':'synthetic review'})
def measurement(v):return {'value':v,'status':'measured','reason':'synthetic','method':'fixture'}
usage={'scope':'exclusive','usage_key':'usage1','provider':'synthetic','model':'fixture','metering_ref':'synthetic','equivalents':[]}
for key,v in zip(T.TOKENS,[100,20,30,10,5]):usage[key]=measurement(v)
step=event('step','step',{'step_key':'step1','phase':'review','started_at':now,'ended_at':'2026-11-01T00:00:02Z','duration_ms':2000,'status':'succeeded','attempt':1,'trace_id':'1'*32,'span_id':'2'*16,'parent_step_ref':None,'usage':usage})
message=event('message','message',{'conversation_id':'chat1','message_id':'message1','turn_id':'turn1','role':'user','visibility':'user_visible','content_ref':'synthetic','step_ref':'step','occurred_at':now},['source','step'])
end=event('end','request_end',{'status':'completed','occurred_at':'2026-11-01T00:00:05Z'})
base=[source,agent,request,step,message,end]
db=OUT/'ledger.sqlite';L['initialize'](db)
test('valid atomic ingest',lambda:eq(L['ingest'](db,tenant,base)['inserted'],6))
test('identical replay',lambda:eq(L['ingest'](db,tenant,base)['replayed'],6))
test('exact independent statistics',lambda:eq({k:v for k,v in T.summarize(L['query'](db,tenant),'request')['groups']['request'].items() if k in ['known_measured_tokens','request_wall_ms','step_duration_ms','dialogue_rounds','steps']},{'known_measured_tokens':120,'request_wall_ms':5000.0,'step_duration_ms':2000,'dialogue_rounds':1,'steps':1}))
test('tenant isolation',lambda:eq(L['query'](db,'other'),[]))
bad=copy.deepcopy(step);bad['record_id']='bad';bad['payload']['step_key']='step2';bad['payload']['usage']['usage_key']='usage2';bad['payload']['event_key']='bad';bad['payload']['duration_ms']=3
test('duration validation',lambda:reject(lambda:L['ingest'](db,tenant,[bad])))
test('batch rollback',lambda:(reject(lambda:L['ingest'](db,tenant,[event('msg2','message',{**message['payload'],'event_key':'msg2','message_id':'msg2'} ,['source','step']),bad])),eq(len(L['query'](db,tenant)),6)))
dup=copy.deepcopy(step);dup['record_id']='dup';dup['payload']['event_key']='dup'
test('logical usage deduplication',lambda:reject(lambda:L['ingest'](db,tenant,[dup])))
corr=copy.deepcopy(step);corr['record_id']='step-corrected';corr['supersedes']='step';corr['payload']['source_revision']='2';corr['payload']['usage']['input_tokens']['value']=110
test('step correction preserves raw related facts',lambda:(L['ingest'](db,tenant,[corr]),eq(T.summarize(L['query'](db,tenant,step='step'),'step')['groups']['step1']['known_measured_tokens'],130),eq(T.summarize(L['query'](db,tenant,step='step'),'step')['groups']['step1']['dialogue_rounds'],1)))
analysis=rec('analysis','analysis',{'question':'q','method':'synthetic','sample':1,'findings':'synthetic','counterevidence':'none','limitations':'synthetic','target':{'scope':'agent','agent_ref':'agent'}},['step-corrected'])
L['ingest'](db,tenant,[analysis])
opt=rec('opt','optimization',{'target_layer':'agent','target':{'scope':'agent','agent_ref':'agent'},'problem':'synthetic','proposed_change':'synthetic','metrics':'synthetic','validation_plan':'synthetic','rollback':'synthetic','owner_ref':'synthetic','status':'proposed'},['analysis'])
test('subagent proposed optimization allowed',lambda:eq(L['ingest'](db,tenant,[opt])['inserted'],1))
for scope in ['framework','yuanheng','unknown']:
 badopt=copy.deepcopy(opt);badopt['record_id']='opt-'+scope;badopt['payload']['target_layer']=scope;badopt['payload']['target']['scope']=scope
 test(scope+' optimization denied',lambda b=badopt:reject(lambda:L['ingest'](db,tenant,[b])))
owner=OUT/'candidate';test('create candidate without permission grant',lambda:eq(C['create'](ROOT,owner,'skill','synthetic-review','Independent synthetic test')['approval_granted'],False))
ob=OUT/'outbox.sqlite';dest=OUT/'delivery.sqlite';L['initialize'](dest)
binding={'template':False,'tenant_id':tenant,'source_ref':'source','agent_snapshot_ref':'agent','request_ref':'request','outbox_path':str(ob.resolve()),'sink_ref':str(dest.resolve()),'authority_ref':'synthetic'}
test('template binding rejected',lambda:reject(lambda:R['enqueue'](ROOT,ob,tenant,'template',base,{**binding,'template':True},owner)))
test('enqueue does not claim delivered',lambda:eq(R['enqueue'](ROOT,ob,tenant,'valid',base,binding,owner)['delivered'],False))
test('flush returns actual receipt',lambda:eq(R['flush'](ROOT,ob,dest)['results'][0]['receipt']['inserted'],6))
test('queue replay no duplicate ledger facts',lambda:(eq(R['enqueue'](ROOT,ob,tenant,'valid',base,binding,owner)['delivered'],True),eq(len(L['query'](dest,tenant)),6)))
test('batch key changed data rejected',lambda:reject(lambda:R['enqueue'](ROOT,ob,tenant,'valid',base[:-1],binding,owner)))
# Simulate a crash after ledger commit, before outbox acknowledgement.
with sqlite3.connect(ob) as cx:cx.execute("UPDATE submissions SET status='pending',receipt=NULL,delivered_at=NULL")
test('commit-before-ack crash recovery',lambda:eq(R['flush'](ROOT,ob,dest)['results'][0]['receipt']['replayed'],6))
# Failure isolation: poison first item must not permanently starve a later independent batch.
po=OUT/'poison.sqlite';pb={**binding,'outbox_path':str(po.resolve())}
R['enqueue'](ROOT,po,tenant,'bad-first',[bad],pb,owner)
newmsg=event('newmessage','message',{**message['payload'],'event_key':'newmessage','message_id':'newmessage'},['source','step'])
R['enqueue'](ROOT,po,tenant,'valid-next',[newmsg],pb,owner)
attempts=[R['flush'](ROOT,po,dest,1) for _ in range(3)]
test('poison batch does not starve later batch',lambda:eq([x['status'] for x in R['status'](po,tenant)],['pending','sent']))
recover=OUT/'recover.sqlite';recoverdb=OUT/'recover-dest.sqlite';rb={**binding,'outbox_path':str(recover.resolve()),'sink_ref':str(recoverdb.resolve())}
R['enqueue'](ROOT,recover,tenant,'recover',base,rb,owner)
test('temporary missing sink stays pending',lambda:eq(R['flush'](ROOT,recover,recoverdb)['results'][0]['status'],'pending'))
L['initialize'](recoverdb)
test('temporary sink recovery delivers',lambda:eq(R['flush'](ROOT,recover,recoverdb)['results'][0]['receipt']['inserted'],6))
if 'last_attempt_seq' in (ROOT/'tools/diting-report.py').read_text(encoding='utf8'):
 migrated=OUT/'v1-outbox.sqlite';shutil.copyfile(Path(__file__).parent/'baseline'/'outbox.sqlite',migrated)
 with sqlite3.connect(migrated) as cx:before=cx.execute('SELECT * FROM submissions').fetchall()
 cx=R['connect'](migrated)
 version=cx.execute('PRAGMA user_version').fetchone()[0];after=cx.execute('SELECT * FROM submissions').fetchall();cx.close()
 test('v1 outbox migration keeps original 15 fields',lambda:(eq(version,2),eq([r[:15] for r in after],before),eq([r[15] for r in after],[0]*len(before))))
details={'framework':str(ROOT),'tests':tests,'poison_attempts':attempts,'scope':'independent synthetic local code only; host auto-collection not implemented','sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'framework-manifest.json',ROOT/'tools/diting-report.py',ROOT/'agents/diting/scripts/telemetry.py',ROOT/'agents/diting/scripts/ledger.py']}}
(OUT/'results.json').write_text(json.dumps(details,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(details,ensure_ascii=False,indent=2))
