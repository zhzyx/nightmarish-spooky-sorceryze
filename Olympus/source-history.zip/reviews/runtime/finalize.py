from pathlib import Path
import json,hashlib,subprocess,sys,runpy,shutil
W=Path(__file__).parent;root=Path(sys.argv[1]).resolve();dest=W/'candidate-gates';dest.mkdir(exist_ok=True);clone=dest/'copy';shutil.copytree(root,clone,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
m=json.loads((root/'framework-manifest.json').read_text(encoding='utf8'));gates=[]
def gate(name,cmd,expected):
 p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8');gates.append({'name':name,'pass':(p.returncode==0)==expected,'code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
gate('candidate integrity', [sys.executable,str(clone/'tools/verify_framework.py'),'--candidate'],True)
gate('unapproved candidate full gate closed', [sys.executable,str(clone/'tools/verify_framework.py')],False)
for a in m['agents']:gate(a['id']+' unapproved admission closed',['node',str(clone/'tools/admission.mjs'),str(clone),a['id']],False)
gate('candidate reporting all12',['node',str(clone/'tools/reporting.mjs'),'--all',str(clone)],True)
extra=clone/'agents'/'unexpected';extra.mkdir();(extra/'agent.json').write_text('{}')
gate('candidate detects unregistered agent',[sys.executable,str(clone/'tools/verify_framework.py'),'--candidate'],False);shutil.rmtree(extra)
extra=clone/'skills'/'unexpected';extra.mkdir();(extra/'SKILL.md').write_text('synthetic')
gate('candidate detects unregistered skill',[sys.executable,str(clone/'tools/verify_framework.py'),'--candidate'],False);shutil.rmtree(extra)
api=runpy.run_path(str(root/'tools/verify_framework.py'))
bindings=[]
for a in m['agents']:
 actual={p.relative_to(root).as_posix() for p in (root/'agents'/a['id']).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 recomputed=api['fingerprint'](root,a['candidate_files'])[0]
 bindings.append({'id':a['id'],'version':a['version'],'candidate_digest':a['candidate_digest'],'recomputed_digest':recomputed,'match':recomputed==a['candidate_digest'],'owned_file_count':len(actual),'owned_files_missing_from_fingerprint':sorted(actual-set(a['candidate_files']))})
paths=['framework-manifest.json','FOUNDATION.md','tools/admission.mjs','tools/reporting.mjs','tools/agent-context.mjs','tools/verify_framework.py','tools/create-component.py','tools/diting-report.py','agents/diting/scripts/ledger.py','agents/diting/scripts/telemetry.py']
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
baseline=json.loads((W/'baseline/results.json').read_text(encoding='utf8'));admission=json.loads((W/'admission-baseline-corrected/results.json').read_text(encoding='utf8'));candidate=json.loads((W/'candidate/results.json').read_text(encoding='utf8'))
result={'reviewer':'xiezhi_runtime_review','display_role':'獬豸·框架审查（临时独立运行验证职能，受元衡控制）','status':'pass_local_code_and_definition_review','not_approval':True,'scope':'local synthetic execution and definition integrity; excludes host identity/authentication, live automatic collection and ToB concurrency qualification','candidate_framework':str(root),'sha256':hashes,'agent_bindings':bindings,'baseline_runtime':baseline,'baseline_admission':admission,'candidate_runtime':candidate,'candidate_gates':gates,'findings':[{'id':'RUNTIME-01','severity':'P2','summary':'Failed pending queue prefix starves later valid batches','status':'fixed_and_independently_retested','repro':'probe.py baseline: poison batch then valid batch; three flush(limit=1) calls all retry poison','fix':'schema2 last_attempt_seq rotation; v1 migration preserving original fields','candidate_result':'23 of 23 independent runtime checks pass'}],'known_limits':['Host auto event collection is not implemented; all databases contain isolated synthetic data.','Local approval records do not authenticate actual user or host authority.','SQLite tests are correctness checks, not enterprise concurrency, performance or fault-injection qualification.','Direct ledger APIs accept synthetic caller metadata; host access/identity checks remain outside these local tools.'],'test_harness_note':'First admission harness run used an invalid guessed root CLI argument. Corrected run is admission-baseline-corrected; initial run is not counted as evidence.'}
(W.parent/'runtime-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
report=f'''# 獬豸·框架审查：独立运行验证

临时职能，受元衡控制。结论：候选 0.8.1 的本地代码与定义范围复核通过；本报告不是批准通行证，也不证明宿主自动采集已上线。

## 审查依据与范围

回查共工 gonggong-check、冻结 FOUNDATION 1.0、元衡标准及 reporting 契约。独立阅读并核查 admission/reporting/create-component/diting-report/verify_framework/agent-context 与谛听 ledger/telemetry。框架文件未被本审查者修改。全部运行数据为 work/full-review/runtime 内隔离合成数据。

## 发现与修复复核

RUNTIME-01（P2）：0.8 的 flush 将 pending 按 rowid 取前 limit 项，永久错误项保持原位置，能够使后面的有效批次一直不被尝试。独立反例中，先排入 duration_ms 与时间戳冲突的批次，再排入有效消息；连续三次 limit=1 均只失败于首批次。

0.8.1 使用 last_attempt_seq 轮转；复测中第一轮错误、第二轮有效消息落库、第三轮错误仍能重试。v1→v2 outbox 迁移逐字段保留原 15 字段及载荷/回执；新序列字段为 0。缺失 sink 导致 pending 后，初始化 sink 可成功重试。缺陷已关闭。

## 独立证据

- 0.8 独立运行 20 项：19 通过、1 项上述缺陷；修复后独立运行 23 项全部通过。
- 0.8 准入/登记/上报配置 31 项通过：逐个测试三 Agent 的待审、模板、自批、过期、范围扩大、入口变更拒绝；上下文、实际登记及 12 配置校验。
- 0.8.1 候选门禁 {len(gates)} 项全部通过：candidate 完整性、12 配置、无批准时拒绝准入、未登记 Agent/skill 被拒绝。
- 实际 SQLite 统计：100 输入+20 输出=120 token；缓存和推理子集不再相加；步骤 2 秒、需求墙钟 5 秒、对话 1 轮。更正步骤后为 130 token，原消息仍计 1 轮。
- 幂等重放、批次冲突拒绝、事务回滚、租户隔离、步骤稳定标识去重、落库后未 ack 的重试恢复均通过。
- 子 Agent 优化建议可入库，framework/yuanheng/unknown 优化被拒绝。创建仅返回候选和配置，不授予权限。
- 三 Agent 的 13/3/19 个自有文件全部纳入候选指纹，重新计算值与清单一致。

原始脚本：runtime/probe.py、runtime/admission_probe.py、runtime/finalize.py。机器证据：runtime-results.json。初次 admission 脚本 CLI 参数错误已修正，未作为通过证据。

## 候选绑定

manifest SHA256：`{hashes['framework-manifest.json']}`

FOUNDATION SHA256：`{hashes['FOUNDATION.md']}`（保持冻结原件）

'''
for a in bindings:report+=f"- {a['id']} {a['version']}：`{a['candidate_digest']}`\n"
report+='''
## 边界与元衡评价

Purpose：验证具体生产上报需求；Truth：合成数据、故障和未知项均明示；Economy：复用共享 reporter，无新增常设 Agent/skill；Authority：待批候选拒绝准入，本报告不替代授权；Adaptation：依据可复现失败修复且保留重试证据；Continuity：冻结纲领及元衡原件未改，统计与幂等回归通过。

未验证真实宿主身份/权限认证、所有对话事件自动采集、供应商实际 token 回传、企业级高并发或生产服务可用性。SQLite 正确性不等于 ToB 规模验证。不能据此声称“无优化空间”或“全自动上报已经启用”。
'''
(W.parent/'runtime-review.md').write_text(report,encoding='utf8')
print(json.dumps({'runtime_pass':sum(t['pass'] for t in candidate['tests']),'runtime_total':len(candidate['tests']),'admission_pass':sum(t['pass'] for t in admission['tests']),'admission_total':len(admission['tests']),'candidate_gates':gates,'bindings':bindings,'manifest_sha':hashes['framework-manifest.json']},ensure_ascii=False))
