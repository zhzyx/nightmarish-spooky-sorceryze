# 獬豸·框架审查：独立运行验证

临时职能，受元衡控制。结论：候选 0.8.1 的本地代码与定义范围复核通过；本报告不是批准通行证，也不证明宿主自动采集已上线。

## 审查依据与范围

回查共工 gonggong-check、冻结 FOUNDATION 1.0、元衡标准及 reporting 契约。独立阅读并核查 admission/reporting/create-component/diting-report/verify_framework/agent-context 与谛听 ledger/telemetry。框架文件未被本审查者修改。全部运行数据为 work/full-review/runtime 内隔离合成数据。

## 发现与修复复核

RUNTIME-01（P2）：0.8 的 flush 将 pending 按 rowid 取前 limit 项，永久错误项保持原位置，能够使后面的有效批次一直不被尝试。独立反例中，先排入 duration_ms 与时间戳冲突的批次，再排入有效消息；连续三次 limit=1 均只失败于首批次。

0.8.1 使用 last_attempt_seq 轮转；复测中第一轮错误、第二轮有效消息落库、第三轮错误仍能重试。v1→v2 outbox 迁移逐字段保留原 15 字段及载荷/回执；新序列字段为 0。缺失 sink 导致 pending 后，初始化 sink 可成功重试。缺陷已关闭。

## 独立证据

- 0.8 独立运行 20 项：19 通过、1 项上述缺陷；修复后独立运行 23 项全部通过。
- 0.8 准入/登记/上报配置 31 项通过：逐个测试三 Agent 的待审、模板、自批、过期、范围扩大、入口变更拒绝；上下文、实际登记及 12 配置校验。
- 0.8.1 候选门禁 8 项全部通过：candidate 完整性、12 配置、无批准时拒绝准入、未登记 Agent/skill 被拒绝。
- 实际 SQLite 统计：100 输入+20 输出=120 token；缓存和推理子集不再相加；步骤 2 秒、需求墙钟 5 秒、对话 1 轮。更正步骤后为 130 token，原消息仍计 1 轮。
- 幂等重放、批次冲突拒绝、事务回滚、租户隔离、步骤稳定标识去重、落库后未 ack 的重试恢复均通过。
- 子 Agent 优化建议可入库，framework/yuanheng/unknown 优化被拒绝。创建仅返回候选和配置，不授予权限。
- 三 Agent 的 13/3/19 个自有文件全部纳入候选指纹，重新计算值与清单一致。

原始脚本：runtime/probe.py、runtime/admission_probe.py、runtime/finalize.py。机器证据：runtime-results.json。初次 admission 脚本 CLI 参数错误已修正，未作为通过证据。

## 候选绑定

manifest SHA256：`18a32592f66df2a50ea894ad6806bb1ab60edcb063b7962d35cb445d218d12ca`

FOUNDATION SHA256：`af0b14934f8998ac7e751475f8192f52adbeb3a26e3d709ee083bcbfeb42148f`（保持冻结原件）

- yanshi 0.3.1：`a36f61efdb74df0e007e479838cd9043d79b7efe3298903eadd93137b493d14e`
- kuafu 0.3.1：`bcaac36a247b5e5202a9c53d58e390889d5cb4961bb7d0e4e854c95dada9ce66`
- diting 0.3.1：`e375dcfe077889a960d3aaf3dfebd14f18614f19f34f9183b66ffee0ace2fc3f`

## 边界与元衡评价

Purpose：验证具体生产上报需求；Truth：合成数据、故障和未知项均明示；Economy：复用共享 reporter，无新增常设 Agent/skill；Authority：待批候选拒绝准入，本报告不替代授权；Adaptation：依据可复现失败修复且保留重试证据；Continuity：冻结纲领及元衡原件未改，统计与幂等回归通过。

未验证真实宿主身份/权限认证、所有对话事件自动采集、供应商实际 token 回传、企业级高并发或生产服务可用性。SQLite 正确性不等于 ToB 规模验证。不能据此声称“无优化空间”或“全自动上报已经启用”。
