# 司南｜工单管理与协调

司南为工单辨方向、排先后。业务规则见《工单管理体系》。工具读取现有元衡账本，支持维护协调标签，不建立第二套执行状态，不复制元衡组件。版本 0.2.1。司南覆盖各类任务，研究、运营、内容、设计、事务和开发均可纳入；类型按业务扩展，Feature 关联仅在适用时填写。

按需能力入口为 `skills/work-order-coordination/SKILL.md`，共享专项为 `specs/work-order-management.md`。总协调是可委托职责，本版没有新增独立 Agent。

```powershell
node coordinator.mjs board registry.json
node coordinator.mjs ready registry.json
node coordinator.mjs prepare registry.json SOURCE start YH-0001 mandate.json
node coordinator.mjs label registry.json "ledger-B::YH-0002" label-change.json
node coordinator.mjs board registry.json type:bug state:processing
node coordinator.mjs board registry.json decision:pending
node coordinator.mjs ready registry.json type:research
```

当前适配器在 registry.json 中登记元衡来源根目录并读取其 `.yuanheng/state.json`。Git 和本地文件凭据是现有适配器的约束，不是所有业务任务的定义；其他来源的连接器尚未实现。初始来源为空，表示尚未接入真实项目，不是已接入项目没有工作。跨账本依赖示例：`{"ticket":"ledger-B::YH-0002","requires":"ledger-A::YH-0001","kind":"hard"}`。

协调记录示例：`{"ticket":"ledger-B::YH-0002","priority":1,"feature_refs":["F-001"],"coordinator":"总协调主责","pending_user":false}`。优先级 0 最先，3 最后；缺省为 2。可派工列表不等于授权或自动执行，不包含真实容量求解。

prepare 返回原 CLI 的 executable 与 argv，不执行命令。实际写入须走原 CLI 和宿主，派发前重读来源、核验授权和跨账本约束。适配器路径引用已有元衡 CLI，移动环境时重新绑定，不能私拷框架。

测试：从本项目根目录执行 `node --test outputs/gonggong-workorders/test/coordinator.test.mjs`。隔离测试数据仅保存在 work，不接入真实账本。

`label-change.json` 示例（工单 ID 替换为已接入的真实 ID）：

```json
{
  "type": "bug",
  "tags": ["登录", "版本1.0"],
  "assessment": {"state":"pending", "owner":"夸父主责实例", "reason":"判断跨模块接口影响", "blocking":true},
  "actor": "实际操作者",
  "reason": "已确认缺陷，需评估跨模块影响"
}
```

可只提交要改的字段；tags 替换该工单全部业务标签，空数组清空。type 为可扩展的主类型标识，例如 research、operations、content、design、coordination、administration、decision、bug、feature，也可用业务自定类型如采购。标识非空、最长 80 字符、不含空白或冒号；缺省 unclassified。这些是示例，不是类型白名单。assessment 可为 pending、resolved、none；resolved 要有 owner、reason、reference，none 清除当前判断标记并保留历史。pending 必填 blocking。该操作不清除 pending_user，不改变授权或源状态。

筛选编码：`type:bug`（Bug），`state:planned`（计划中），`state:processing`（处理中），`state:review`（待验收），`state:blocked`（已阻塞），`state:done`（源账本已完成），`state:awaiting_host`（待宿主接单），`state:unknown`（未知）；`decision:pending`（待判断），`decision:user`（待用户决策），`tag:登录`（业务标签），`attention:required`（需协调）。多条件取交集；board 保留来源诊断，仅过滤工单与候选列表。未分类不等于已排除 Bug，未知筛选条件不匹配任何工单。

label 只写 registry 的 coordination 和 label_history，采用同文件锁及原子替换；board/ready/prepare 仍不写入。生产账本始终由原 CLI 和宿主管理。当前提供命令行能力，尚未接入真实项目或新增图形界面。
