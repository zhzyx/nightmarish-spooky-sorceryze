---
name: work-order-coordination
description: Coordinate registered Gonggong work orders of any business type using authoritative ledgers, dependencies and handoffs. Use for task queues and blockers across development, research, operations and other work; domain judgments stay with their owners.
---

# Work-order coordination

Use the shared Gonggong framework's gonggong-check, project-state and work-order-management specifications for the current responsibility. Reuse already loaded Yuanheng and foundation sources. This skill adds no agent identity, authority, ledger or automatic dispatch.

Resolve the registered sources and coordinator entry in runtime-ref.json. Run board to inspect source health, provenance and blockers; ready gives dispatch candidates, not authorization. Prioritize using the user's actual goals and delegated scope. Use business-appropriate task types and completion criteria; Feature links apply only when relevant. Keep delivery with its accountable owner and escalated quality oversight with Kuafu.

Use prepare only to build a handoff to the existing source CLI and host. It does not execute. Before a real transition, revalidate source versions, cross-ledger constraints, actual capacity and authority; never directly edit a source ledger or treat a host-pending assignment as executed. Unsupported source transitions remain pending adapter work.

Surface only a concrete reserved user choice or meaningful change in delivery. Keep source state, evidence health, coordination status and synchronization distinct. Do not infer that unregistered sources or inaccessible work are covered.
